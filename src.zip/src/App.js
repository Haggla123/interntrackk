import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Main Pages
import Login from './Login';
import Home from './Home';
import Profile from './Profile';


// Organized Dashboards (Inside the pages folder)
import StudentDashboard from './pages/StudentDashboard';
import IndustrialDashboard from './pages/IndustrialDashboard';
import AcademicDashboard from './pages/AcademicDashboard';
import AdminDashboard from './pages/AdminDashboard';

// Shared or Specific Components
import LogbookHistory from './components/student/LogbookHistory';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Landing and Authentication */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          
          {/* Role-Based Dashboard Hubs */}
          {/* These act as "Parent" components that handle their own internal tab switching */}
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/academic" element={<AcademicDashboard />} />
          <Route path="/student" element={<StudentDashboard />} />
          <Route path="/industrial" element={<IndustrialDashboard />} />

          {/* Standalone Views */}
          <Route path="/industrial/my-students" element={<MyStudents />} />
          <Route path="/student/history" element={<LogbookHistory />} />
          
          
          
          {/* Catch-all: Redirect unknown paths to Login */}
          <Route path="*" element={<Login />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;