import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Search, PlusCircle, Link2, FileDown } from 'lucide-react';
import AdminSidebar from '../components/admin/AdminSidebar';
import AdminSettings from '../components/admin/AdminSettings';
import './AdminDashboard.css';
import StudentModal from '../components/admin/StudentModal';
import SupervisorModal from '../components/admin/SupervisorModal';
import AssignmentTab from '../components/admin/AssignmentTab';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [isSupervisorModalOpen, setIsSupervisorModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  const handleLogout = () => navigate('/login');

  // Mock Data
  const supervisors = [
    { id: 1, name: "Dr. Robert Smith", role: "Academic", org: "Computer Science", students: 12 },
    { id: 2, name: "Mrs. Janet Osei", role: "Industrial", org: "Vodafone Ghana", students: 3 }
  ];

  const students = [
    { id: 1, index: "2201093", name: "Kwame Mensah", company: "Vodafone", supervisor: "Dr. Smith" },
    { id: 2, index: "2201095", name: "Abena Selorm", company: "MTN", supervisor: "Dr. Smith" }
  ];

 const renderContent = () => {
    switch (activeTab) {
      case 'supervisors':
        return (
          <div className="content-card fade-in">
            <div className="card-header-actions">
              {/* ... Search bar */}
              <button className="primary-btn" onClick={() => setIsSupervisorModalOpen(true)}>
                New Supervisor
              </button>
            </div>
            {/* ... Table */}
            <SupervisorModal 
              isOpen={isSupervisorModalOpen} 
              onClose={() => setIsSupervisorModalOpen(false)} 
            />
          </div>
        );

      case 'students':
        return (
          <div className="content-card fade-in">
            <div className="card-header-actions">
              {/* ... Search bar */}
              <button className="primary-btn" onClick={() => setIsStudentModalOpen(true)}>
                New Student
              </button>
            </div>
            {/* ... Table */}
            <StudentModal 
              isOpen={isStudentModalOpen} 
              onClose={() => setIsStudentModalOpen(false)} 
            />
          </div>
        );


      case 'assignments':
  return (
    <AssignmentTab 
      students={students} 
      supervisors={supervisors} 
      companies={[]} // You can add your company data here later
    />
  );

      case 'settings':
        return <AdminSettings />;

      case 'overview':
      default:
        return (
          <div className="overview-grid fade-in">
            <div className="stat-card"><h5>Total Students</h5><p>1,240</p></div>
            <div className="stat-card"><h5>Active Firms</h5><p>120</p></div>
            <div className="stat-card alert"><h5>Fraud Alerts</h5><p>5</p></div>
          </div>
        );
    }
  };

  return (
    <div className="admin-wrapper">
      <AdminSidebar 
        activeTab={activeTab} 
        setActiveTab={(tab) => { setActiveTab(tab); setSearchTerm(""); }} 
        handleLogout={handleLogout} 
      />

      <main className="main-area">
        <header className="top-nav">
          <div className="breadcrumb">Dashboard / {activeTab.toUpperCase()}</div>
          <div className="top-nav-right">
            <Bell size={20} />
            <div className="admin-avatar">AD</div>
          </div>
        </header>
        <section className="page-content">{renderContent()}</section>
      </main>
    </div>
  );
};

export default AdminDashboard;