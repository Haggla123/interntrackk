import React from 'react';
import { MapPin, Check, X } from 'lucide-react';

const PendingApprovals = ({ pendingLogs }) => {
  return (
    <div className="content-card fade-in">
      <h3>Pending Logbook Approvals</h3>
      <div className="approval-list">
        {pendingLogs.map(log => (
          <div key={log.id} className="approval-item">
            <div className="log-meta">
              <strong>{log.studentName}</strong>
              <span className="log-date">{log.date}</span>
              <span className="geo-tag"><MapPin size={12}/> {log.locationStatus}</span>
            </div>
            <p className="log-text">"{log.content}"</p>
            <div className="approval-actions">
              <button className="approve-btn"><Check size={16}/> Approve</button>
              <button className="reject-btn"><X size={16}/> Reject</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PendingApprovals;