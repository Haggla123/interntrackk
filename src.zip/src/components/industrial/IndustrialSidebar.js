import React from 'react';
import { Users, CheckSquare, ShieldCheck, User, LogOut } from 'lucide-react';

const IndustrialSidebar = ({ activeTab, setActiveTab, handleLogout, companyName }) => {
  return (
    <aside className="sidebar">
      <div className="sidebar-top">
        <div className="sidebar-brand">
          <div className="logo-icon">I</div>
          <span>UIMS INDUSTRIAL</span>
        </div>
        
        <nav className="sidebar-nav">
          <div className="nav-group">
            <label>{companyName}</label>
            <li className={activeTab === 'interns' ? 'active' : ''} onClick={() => setActiveTab('interns')}>
              <Users size={20} /> My Interns
            </li>
            <li className={activeTab === 'approvals' ? 'active' : ''} onClick={() => setActiveTab('approvals')}>
              <CheckSquare size={20} /> Pending Approvals
            </li>
          </div>
        </nav>
      </div>

      <div className="sidebar-footer">
        <li onClick={() => setActiveTab('profile')}><ShieldCheck size={20} /> Company Profile</li>
        <button className="logout-btn" onClick={handleLogout}><LogOut size={20} /> Logout</button>
      </div>
    </aside>
  );
};

export default IndustrialSidebar;