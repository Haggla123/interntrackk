import React from 'react';
import { BookOpen, History, User, LogOut, Clock } from 'lucide-react';

const StudentSidebar = ({ activeTab, setActiveTab, handleLogout, studentName }) => {
  return (
    <aside className="sidebar">
      <div className="sidebar-top">
        <div className="sidebar-brand">
          <div className="logo-icon">S</div>
          <span>UIMS STUDENT</span>
        </div>
        
        <nav className="sidebar-nav">
          <div className="nav-group">
            <label>INTERNSHIP</label>
            <li 
              className={activeTab === 'daily-log' ? 'active' : ''} 
              onClick={() => setActiveTab('daily-log')}
            >
              <BookOpen size={20} /> Daily Log
            </li>
            <li 
              className={activeTab === 'history' ? 'active' : ''} 
              onClick={() => setActiveTab('history')}
            >
              <History size={20} /> Logbook History
            </li>
          </div>

          <div className="nav-group">
            <label>ACCOUNT</label>
            <li 
              className={activeTab === 'profile' ? 'active' : ''} 
              onClick={() => setActiveTab('profile')}
            >
              <User size={20} /> My Profile
            </li>
          </div>
        </nav>
      </div>

      <div className="sidebar-footer">
        <div className="user-mini-profile">
          <div className="avatar-sm">{studentName.charAt(0)}</div>
          <div className="user-info-sm">
            <span>{studentName}</span>
            <small>Intern</small>
          </div>
        </div>
        <button className="logout-btn" onClick={handleLogout}>
          <LogOut size={20} /> Logout
        </button>
      </div>
    </aside>
  );
};

export default StudentSidebar;