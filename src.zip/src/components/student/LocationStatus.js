import React, { useState, useEffect } from 'react';
import { MapPin, RefreshCw, CheckCircle, AlertTriangle } from 'lucide-react';

const LocationStatus = ({ targetLat, targetLon, radius, onVerificationChange }) => {
  const [loading, setLoading] = useState(false);
  const [distance, setDistance] = useState(null);
  const [status, setStatus] = useState('pending'); // 'pending', 'verified', 'failed'

  // Haversine formula to calculate distance between two GPS points
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371000; // Radius of Earth in meters
    const dLat = (lat2 - lat1) * (Math.PI / 180);
    const dLon = (lon2 - lon1) * (Math.PI / 180);
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c; // Distance in meters
  };

  const verifyLocation = () => {
    setLoading(true);
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser");
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const userLat = position.coords.latitude;
        const userLon = position.coords.longitude;
        
        const dist = calculateDistance(userLat, userLon, targetLat, targetLon);
        setDistance(Math.round(dist));

        if (dist <= radius) {
          setStatus('verified');
          onVerificationChange(true);
        } else {
          setStatus('failed');
          onVerificationChange(false);
        }
        setLoading(false);
      },
      (error) => {
        console.error(error);
        setStatus('failed');
        setLoading(false);
      }
    );
  };

  return (
    <div className={`location-card ${status}`}>
      <div className="location-header">
        <MapPin size={20} />
        <h4>Presence Verification</h4>
      </div>
      
      <div className="location-body">
        {status === 'pending' && <p>Please verify your location to start logging.</p>}
        {status === 'verified' && <p><CheckCircle size={16}/> You are at your workplace.</p>}
        {status === 'failed' && <p><AlertTriangle size={16}/> Outside geofence ({distance}m away).</p>}
        
        <button 
          className="verify-btn" 
          onClick={verifyLocation} 
          disabled={loading}
        >
          {loading ? <RefreshCw className="spin" size={16} /> : "Check My Location"}
        </button>
      </div>
    </div>
  );
};

export default LocationStatus;