import React, { useState } from 'react';
import { Send, MapPin } from 'lucide-react';

const LogEntryForm = ({ isLocationVerified }) => {
  const [entry, setEntry] = useState("");

  return (
    <div className="content-card fade-in">
      <div className="card-header">
        <h3>Daily Work Log</h3>
        <p>Record your activities for today. Must be within company premises.</p>
      </div>

      <div className={`location-banner ${isLocationVerified ? 'verified' : 'failed'}`}>
        <MapPin size={18} />
        {isLocationVerified ? "Location Verified: You are at Vodafone HQ" : "Location Error: You are outside the geofence"}
      </div>

      <form className="log-form" onSubmit={(e) => e.preventDefault()}>
        <textarea 
          placeholder="Describe the tasks you completed today..."
          value={entry}
          onChange={(e) => setEntry(e.target.value)}
          disabled={!isLocationVerified}
        />
        <div className="form-footer">
          <span className="char-count">{entry.length} characters</span>
          <button 
            type="submit" 
            className="primary-btn" 
            disabled={!isLocationVerified || entry.length < 10}
          >
            <Send size={18} /> Submit Entry
          </button>
        </div>
      </form>
    </div>
  );
};

export default LogEntryForm;