import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, ChevronUp, CheckCircle, XCircle, Clock, FileText } from 'lucide-react';
import './LogbookHistory.css';

const LogbookHistory = () => {
  const navigate = useNavigate();
  const [openWeek, setOpenWeek] = useState(null); // Tracks which week is expanded

  // Mock data structured by weeks
  const weeklyData = [
    {
      weekNumber: 4,
      dates: "Feb 16 - Feb 20",
      logs: [
        { day: "Friday", date: "Feb 20", task: "Server Rack Maintenance", status: "Approved" },
        { day: "Thursday", date: "Feb 19", task: "IP Configuration", status: "Approved" },
        { day: "Wednesday", date: "Feb 18", task: "Switch Port Security", status: "Pending" },
        { day: "Tuesday", date: "Feb 17", task: "Fiber Splicing Demo", status: "Approved" },
        { day: "Monday", date: "Feb 16", task: "Weekly Briefing", status: "Approved" },
      ]
    },
    {
      weekNumber: 3,
      dates: "Feb 09 - Feb 13",
      logs: [
        { day: "Friday", date: "Feb 13", task: "Database Backup", status: "Approved" },
        { day: "Thursday", date: "Feb 12", task: "Schema Migration", status: "Rejected" },
        { day: "Wednesday", date: "Feb 11", task: "SQL Optimization", status: "Approved" },
        { day: "Tuesday", date: "Feb 10", task: "Unit Testing", status: "Approved" },
        { day: "Monday", date: "Feb 09", task: "Project Kickoff", status: "Approved" },
      ]
    }
  ];

  const toggleWeek = (weekNum) => {
    setOpenWeek(openWeek === weekNum ? null : weekNum);
  };

  return (
    <div className="history-page">
      <header className="history-header">
        <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>
        <h1>Full Logbook History</h1>
        <p>Manage and review your 6-week internship record</p>
      </header>

      <div className="accordion-container">
        {weeklyData.map((week) => (
          <div key={week.weekNumber} className={`week-section ${openWeek === week.weekNumber ? 'open' : ''}`}>
            {/* Week Header - Clickable */}
            <div className="week-header" onClick={() => toggleWeek(week.weekNumber)}>
              <div className="week-title">
                <span className="week-badge">Week {week.weekNumber}</span>
                <span className="week-dates">{week.dates}</span>
              </div>
              <div className="week-controls">
                <span className="entry-count">{week.logs.length}/5 Logs Submitted</span>
                {openWeek === week.weekNumber ? <ChevronUp /> : <ChevronDown />}
              </div>
            </div>

            {/* Week Content - Dropdown list of 5 days */}
            {openWeek === week.weekNumber && (
              <div className="week-content animated-slide-down">
                {week.logs.map((log, idx) => (
                  <div key={idx} className="day-row">
                    <div className="day-meta">
                      <span className="day-name">{log.day}</span>
                      <span className="day-date">{log.date}</span>
                    </div>
                    <div className="day-task">
                      <FileText size={16} /> {log.task}
                    </div>
                    <div className={`day-status ${log.status.toLowerCase()}`}>
                      {log.status === 'Approved' && <CheckCircle size={14} />}
                      {log.status === 'Pending' && <Clock size={14} />}
                      {log.status === 'Rejected' && <XCircle size={14} />}
                      {log.status}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default LogbookHistory;