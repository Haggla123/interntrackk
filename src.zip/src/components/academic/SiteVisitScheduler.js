import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, CheckCircle, Plus } from 'lucide-react';
import './SiteVisitScheduler.css';

const SiteVisitScheduler = () => {
  const [selectedStudent, setSelectedStudent] = useState("");
  const [visitDate, setVisitDate] = useState("");
  const [visitTime, setVisitTime] = useState("");

  const assignedStudents = [
    { id: 1, name: "Kwame Mensah", company: "Vodafone Ghana HQ" },
    { id: 2, name: "Abena Selorm", company: "MTN Ghana" },
    { id: 3, name: "John Doe", company: "ECG" },
  ];

  const upcomingVisits = [
    { id: 101, student: "Kwame Mensah", company: "Vodafone", date: "2026-03-05", time: "10:00 AM", status: "Confirmed" },
  ];

  const handleSchedule = (e) => {
    e.preventDefault();
    alert(`Visit scheduled for ${selectedStudent} on ${visitDate}`);
    // Logic to save this will go to the Node.js backend later
  };

  return (
    <div className="scheduler-container">
      <div className="scheduler-grid">
        
        {/* LEFT: Scheduling Form */}
        <div className="schedule-form-card">
          <h3><Plus size={20} /> Schedule New Visit</h3>
          <form onSubmit={handleSchedule}>
            <div className="form-group">
              <label><User size={14} /> Select Student</label>
              <select 
                value={selectedStudent} 
                onChange={(e) => setSelectedStudent(e.target.value)}
                required
              >
                <option value="">-- Choose a student --</option>
                {assignedStudents.map(s => (
                  <option key={s.id} value={s.name}>{s.name} ({s.company})</option>
                ))}
              </select>
            </div>

            <div className="form-row">
              <div className="form-group">
                <label><Calendar size={14} /> Date</label>
                <input 
                  type="date" 
                  value={visitDate} 
                  onChange={(e) => setVisitDate(e.target.value)} 
                  required 
                />
              </div>
              <div className="form-group">
                <label><Clock size={14} /> Time</label>
                <input 
                  type="time" 
                  value={visitTime} 
                  onChange={(e) => setVisitTime(e.target.value)} 
                  required 
                />
              </div>
            </div>

            <button type="submit" className="confirm-btn">Confirm Schedule</button>
          </form>
        </div>

        {/* RIGHT: Upcoming Visits List */}
        <div className="upcoming-visits-card">
          <h3>Upcoming Site Visits</h3>
          <div className="visit-timeline">
            {upcomingVisits.map(visit => (
              <div key={visit.id} className="visit-item">
                <div className="visit-date-badge">
                  <span className="month">MAR</span>
                  <span className="day">05</span>
                </div>
                <div className="visit-details">
                  <h4>{visit.student}</h4>
                  <p><MapPin size={12} /> {visit.company}</p>
                  <p><Clock size={12} /> {visit.time}</p>
                </div>
                <span className="visit-status">{visit.status}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};

export default SiteVisitScheduler;