import React from 'react';

const AcademicOverview = ({ students, onGradeClick }) => {
  return (
    <>
      <div className="welcome-banner">
        <h1>Assigned Students Oversight</h1>
        <p>Monitor and grade the progress of your {students.length} assigned interns.</p>
      </div>
      <div className="student-grid">
        {students.map(student => (
          <div key={student.id} className="student-card">
            <div className="student-info">
              <h3>{student.name}</h3>
              <p className="company-tag">{student.company}</p>
            </div>
            <div className="progress-section">
              <label>Internship Progress</label>
              <div className="progress-bar-bg">
                <div className="progress-bar-fill" style={{width: `${student.progress}%`}}></div>
              </div>
              <span>{student.progress}% Complete</span>
            </div>
            <div className="visit-info">
              <p>Last Physical Visit: <strong>{student.lastVisit}</strong></p>
            </div>
            <div className="action-buttons">
              <button className="grade-btn" onClick={onGradeClick}>Grade Reports</button>
              <button className="visit-btn">Log Visit</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default AcademicOverview;