import React from 'react';

const AcademicSidebar = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'overview', label: 'Overview' },
    { id: 'assigned', label: 'Assigned Students' },
    { id: 'grading', label: 'Grading' },
    { id: 'visits', label: 'Schedule Site Visits' },
    { id: 'settings', label: 'Settings' },
  ];

  return (
    <nav className="academic-nav">
      <ul>
        {menuItems.map((item) => (
          <li
            key={item.id}
            className={activeTab === item.id ? 'active' : ''}
            onClick={() => setActiveTab(item.id)}
          >
            {item.label}
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default AcademicSidebar;