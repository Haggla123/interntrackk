import React, { useState } from 'react';
import { Phone, Mail, Building, User, MapPin, X, ExternalLink, Search } from 'lucide-react';
import './AssignedStudents.css';

const AssignedStudents = () => {
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const students = [
    { id: 1, name: "Amponsah Peter", index: "UEB3211322", company: "Vodafone Ghana HQ", phone: "+233 24 123 4567", email: "k.mensah@univ.edu.gh", supervisor: "Mr. Robert Azu", location: "Airport City, Accra", progress: 85 },
    { id: 2, name: "Shaibu Karim Mustapha", index: "UEB3205122", company: "MTN Ghana", phone: "+233 55 987 6543", email: "a.selorm@univ.edu.gh", supervisor: "Mrs. Janet Osei", location: "Independence Ave, Ridge", progress: 40 },
    { id: 3, name: "Anane Benedicta Ohenewaa", index: "UEB3204122", company: "Bank of Ghana", phone: "+233 20 554 3210", email: "j.doe@univ.edu.gh", supervisor: "Samuel Bekoe", location: "Makola, Central Accra", progress: 90 },
    { id: 4, name: "Kyeremaa Helina", index: "UEB3209322", company: "ECG", phone: "+233 20 555 4321", email: "j.doe@univ.edu.gh", supervisor: "Samuel Bekoe", location: "Makola, Central Accra", progress: 10 },
    { id: 5, name: "Agyei Mensah Haggla", index: "UEB3214522", company: "New Mount", phone: "+233 20 555 1234", email: "j.doe@univ.edu.gh", supervisor: "Samuel Bekoe", location: "Makola, Central Accra", progress: 49 },
  ];

  // UPDATED LOGIC: Searches both Name and Index Number
  const filteredStudents = students.filter(s => 
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    s.index.toString().includes(searchTerm)
  );

  return (
    <div className="assigned-container">
      <div className={`list-section ${selectedStudent ? 'drawer-open' : ''}`}>
        <div className="list-header-flex">
          <div>
            <h2>My Assigned Interns</h2>
            <p>Search by name or index number (e.g., 2201...)</p>
          </div>
          
          <div className="search-box">
            <Search size={18} className="search-icon" />
            <input 
              type="text" 
              placeholder="Search Name or Index..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        <table className="students-table">
          <thead>
            <tr>
              <th>Name & Index</th>
              <th>Assigned Company</th>
              <th>Progress</th>
              <th>Quick View</th>
            </tr>
          </thead>
          <tbody>
            {filteredStudents.length > 0 ? (
              filteredStudents.map(s => (
                <tr key={s.id} className={selectedStudent?.id === s.id ? 'active-row' : ''}>
                  <td>
                    <div className="name-cell">
                      <strong>{s.name}</strong>
                      <span>{s.index}</span>
                    </div>
                  </td>
                  <td>{s.company}</td>
                  <td>
                    <div className="table-progress">
                      <div className="bar"><div className="fill" style={{width: `${s.progress}%`}}></div></div>
                      <span>{s.progress}%</span>
                    </div>
                  </td>
                  <td>
                    <button className="details-btn" onClick={() => setSelectedStudent(s)}>
                      Profile <ExternalLink size={14} />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="no-results">
                  No matches for <strong>"{searchTerm}"</strong>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Sliding Drawer (Stays the same) */}
      <div className={`info-drawer ${selectedStudent ? 'show' : ''}`}>
        {selectedStudent && (
          <div className="drawer-inner">
            <button className="close-btn" onClick={() => setSelectedStudent(null)}><X size={24}/></button>
            <div className="drawer-profile">
              <div className="drawer-avatar">{selectedStudent.name.charAt(0)}</div>
              <h3>{selectedStudent.name}</h3>
              <p className="drawer-sub">{selectedStudent.index}</p>
            </div>
            <div className="drawer-content">
              <div className="content-group">
                <label><User size={14}/> Student Contact</label>
                <div className="data-card">
                  <p><Mail size={16} /> {selectedStudent.email}</p>
                  <p><Phone size={16} /> {selectedStudent.phone}</p>
                </div>
              </div>
              <div className="content-group">
                <label><Building size={14}/> Placement Info</label>
                <div className="data-card">
                  <p><strong>Company:</strong> {selectedStudent.company}</p>
                  <p><MapPin size={16} /> {selectedStudent.location}</p>
                  <p><strong>Industrial Sup:</strong> {selectedStudent.supervisor}</p>
                </div>
              </div>
              <div className="drawer-footer">
                <button className="msg-btn">Send Official Message</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AssignedStudents;