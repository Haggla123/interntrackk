import React from 'react';
import './GradingSection.css';

// We accept setActiveTab as a prop from the AcademicDashboard
const GradingSection = ({ setActiveTab }) => {

  // Mock data of students needing grading
  const studentsToGrade = [
    { id: 1, name: "Amponsah Peter", company: "Vodafone", logsSubmitted: 20, grade: "A", status: "Graded" },
    { id: 2, name: "Shaibu Karim Mustapha", company: "MTN", logsSubmitted: 18, grade: "-", status: "Pending Review" },
    { id: 3, name: "Kyeremaa Helina", company: "ECG", logsSubmitted: 27, grade: "A", status: "Graded" },
    { id: 4, name: "Anane Benedicta Ohenewaa", company: "Bank of Ghana", logsSubmitted: 10, grade: "-", status: "Pending Review" },
    { id: 5, name: "Agyei Mensah Haggla", company: "New Mount", logsSubmitted: 5, grade: "-", status: "Underperforming" },
  ];

  return (
    <div className="grading-container">
      <div className="grading-header">
        <h2>Internship Grading Center</h2>
        <p>Review student logbooks to assign final internship grades.</p>
      </div>

      <div className="grading-card">
        <table className="grading-table">
          <thead>
            <tr>
              <th>Student Name</th>
              <th>Assigned Company</th>
              <th>Total Logs</th>
              <th>Current Status</th>
              <th>Final Grade</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {studentsToGrade.map(student => (
              <tr key={student.id}>
                <td><strong>{student.name}</strong></td>
                <td>{student.company}</td>
                <td>{student.logsSubmitted} / 30</td>
                <td>
                  <span className={`status-pill ${student.status.toLowerCase().replace(' ', '-')}`}>
                    {student.status}
                  </span>
                </td>
                <td className="grade-cell">{student.grade}</td>
                <td>
                  {/* FIXED: Now updates the active tab instead of navigating away */}
                  <button 
                    className="view-logbook-btn" 
                    onClick={() => setActiveTab('view-logbook')}
                  >
                    View Logbook
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default GradingSection;