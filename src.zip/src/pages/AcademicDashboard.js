import React, { useState } from 'react';
import '../styles/AcademicDashboard.css';
import AcademicSidebar from '../components/academic/AcademicSidebar';
import AcademicOverview from '../components/academic/AcademicOverview';
import AssignedStudents from '../components/academic/AssignedStudents'; 
import GradingSection from '../components/academic/GradingSection';
import SiteVisitScheduler from '../components/academic/SiteVisitScheduler';

const AcademicDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');

  const myStudents = [
    { id: 101, name: "Kwame Mensah", company: "Vodafone", progress: 85, lastVisit: "2026-02-10" },
    { id: 102, name: "Abena Selorm", company: "MTN", progress: 40, lastVisit: "None" },
    { id: 103, name: "John Doe", company: "ECG", progress: 10, lastVisit: "None" },
  ];

  const renderMainContent = () => {
    switch (activeTab) {
      case 'assigned': return <AssignedStudents />;
      case 'grading': return <GradingSection />;
      case 'visits': return <SiteVisitScheduler />;
      case 'overview':
      default:
        return <AcademicOverview students={myStudents} onGradeClick={() => setActiveTab('grading')} />;
    }
  };

  return (
    <div className="academic-container">
      <header className="academic-header">
        <div className="logo-section"><h2>InternTrack</h2></div>
        <div className="user-profile">Dr. Smith | Computer Science Dept</div>
      </header>

      <div className="academic-layout">
        <AcademicSidebar activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="academic-main">
          {renderMainContent()}
        </main>
      </div>
    </div>
  );
};

export default AcademicDashboard;