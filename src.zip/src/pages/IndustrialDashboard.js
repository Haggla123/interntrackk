import React, { useState } from 'react';
import IndustrialSidebar from '../components/industrial/IndustrialSidebar';
import PendingApprovals from '../components/industrial/PendingApprovals';
import '../styles/IndustrialDashboard.css';

const IndustrialDashboard = () => {
  const [activeTab, setActiveTab] = useState('interns');
  
  const companyInfo = { name: "Vodafone Ghana", supervisor: "Mrs. Janet Osei" };

  const mockPendingLogs = [
    { 
      id: 1, 
      studentName: "Kwame Mensah", 
      date: "Feb 23, 2026", 
      content: "Configured the network routers for the new office wing.", 
      locationStatus: "Verified via GPS" 
    }
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'approvals':
        return <PendingApprovals pendingLogs={mockPendingLogs} />;
      case 'interns':
      default:
        return (
          <div className="overview-grid fade-in">
            <div className="stat-card"><h5>Active Interns</h5><p>3</p></div>
            <div className="stat-card"><h5>Pending Logs</h5><p>1</p></div>
            <div className="stat-card"><h5>Avg Attendance</h5><p>98%</p></div>
          </div>
        );
    }
  };

  return (
    <div className="admin-wrapper">
      <IndustrialSidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        handleLogout={() => window.location.href = '/login'}
        companyName={companyInfo.name}
      />
      <main className="main-area">
        <header className="top-nav">
          <div className="breadcrumb">Industrial Portal / {companyInfo.supervisor}</div>
        </header>
        <section className="page-content">{renderContent()}</section>
      </main>
    </div>
  );
};

export default IndustrialDashboard;