import React, { useState } from 'react';
import StudentSidebar from '../components/student/StudentSidebar';
import LogEntryForm from '../components/student/LogEntryForm';
import ProgressStats from '../components/student/ProgressStats';
import LogbookHistory from '../components/student/LogbookHistory';
import LocationStatus from '../components/student/LocationStatus';
import '../styles/StudentDashboard.css';
import { useNavigate } from 'react-router-dom';


const StudentDashboard = () => {
  // This state controls which component is visible in the main section
  const [activeTab, setActiveTab] = useState('daily-log');
  const [isVerified, setIsVerified] = useState(false);

  // Mock data - In the future, this will come from your MERN backend
  const companyLocation = { lat: 5.5593, lon: -0.1974, radius: 100 };
  const studentInfo = {
    name: "Kwame Mensah",
    indexNumber: "2201093",
    completedWeeks: 3,
    totalWeeks: 6,
    isLocationVerified: true // This will be handled by your GPS logic
  };

  const handleLogout = () => {
    // Logic to clear tokens/session
    window.location.href = '/login';
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'history':
        return <LogbookHistory />;
      case 'profile':
        return (
          <div className="content-card fade-in">
            <h3>My Internship Profile</h3>
            <p><strong>Name:</strong> {studentInfo.name}</p>
            <p><strong>Index:</strong> {studentInfo.indexNumber}</p>
            <p><strong>Status:</strong> Currently Placed at Vodafone Ghana</p>
          </div>
        );
      case 'daily-log':
      default:
        return (
  <>
    <ProgressStats completedWeeks={3} totalWeeks={6} />
    <LocationStatus 
      targetLat={companyLocation.lat} 
      targetLon={companyLocation.lon} 
      radius={companyLocation.radius} 
      onVerificationChange={(val) => setIsVerified(val)}
    />
    <LogEntryForm isLocationVerified={isVerified} />
  </>
);
    }
  };

  return (
    <div className="admin-wrapper">
      <StudentSidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        handleLogout={handleLogout}
        studentName={studentInfo.name}
      />

      <main className="main-area">
        <header className="top-nav">
          <div className="breadcrumb">Student Portal / {activeTab.toUpperCase()}</div>
          <div className="top-nav-right">
            <div className="admin-avatar">{studentInfo.name.charAt(0)}</div>
          </div>
        </header>

        <section className="page-content">
          {renderContent()}
        </section>
      </main>
    </div>
  );
};

export default StudentDashboard;